- This is the spark-shell script for project-5
- Containing:
+ topUsers.scala : to run the script, simply using the `spark-shell -i` command
  and represent the output result by typing `head output/part-00000` in the terminal.
