load data local infile "SellerInfo.dat" into table SellerInfo fields terminated by "|*|";
load data local infile "ItemInfo.dat" into table ItemInfo fields terminated by "|*|";
load data local infile "CategoryInfo.dat" into table CategoryInfo fields terminated by "|*|";
load data local infile "UserInfo.dat" into table UserInfo fields terminated by "|*|";
load data local infile "BidsInfo.dat" into table BidsInfo fields terminated by "|*|";