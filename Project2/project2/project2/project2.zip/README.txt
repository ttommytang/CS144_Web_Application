ItemInfo(<u>ItemId</u>, Name, Currently, Buy_Pirce, First_Bid, Number_of_Bids, Description, Started, Ended, Country, Location, Longitude, Latitude, SellerId)

CategoryInfo(<u>ItemId</u>, <u>Cate</u>)

BidsInfo(<u>ItemId</u>, <u>UserId</u>, <u>time</u>, amount)

UserInfo(<u>UserId</u>, Rating, Location, Country)

SellerInfo(<u>SellerId</u>, Rating)

All tables are in BCNF and 4NF