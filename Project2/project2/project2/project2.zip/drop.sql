drop table if exists ItemInfo;
drop table if exists CategoryInfo;
drop table if exists BidsInfo;
drop table if exists UserInfo;
drop table if exists SellerInfo;